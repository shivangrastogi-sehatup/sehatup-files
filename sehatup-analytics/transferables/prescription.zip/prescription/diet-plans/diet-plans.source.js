const DIET_PLANS = {
  lean_to_weight_gain: {
    condition: "PCOD (Lean Type) with Hairfall, Weakness, Heavy Periods",
    subtitle: "Diet planned considering hormonal imbalance, nutritional deficiency & low body weight",
    meals: [
      {
        time: "Early Morning (7:00–8:00 AM)",
        food: "1 glass lukewarm water + 5 soaked almonds + 2 walnuts + 5–6 soaked black raisins",
        benefit: "Helps improve energy levels, supports hair growth & reduces weakness caused by heavy periods"
      },
      {
        time: "Breakfast (8:30–9:30 AM)",
        food: "Option 1: Paneer sandwich (multigrain bread)  |  Option 2: 2 eggs + 1 toast  |  Option 3: Vegetable poha with peanuts",
        benefit: "High protein + healthy fats help in weight gain, reduce hairfall & support hormonal balance"
      },
      {
        time: "Mid-Morning (11:00–12:00 PM)",
        food: "1 banana / chikoo / mango (seasonal)",
        benefit: "Supports healthy weight gain & maintains energy throughout the day"
      },
      {
        time: "Lunch (1:30–2:30 PM)",
        food: "2 multigrain roti + 1 bowl sabzi + 1 bowl dal/paneer + 1 bowl curd  |  Small portion salad before meal",
        benefit: "Balanced nutrition improves digestion, supports hormones & reduces weakness"
      },
      {
        time: "Evening Snack (5:00–6:00 PM)",
        food: "Tea (light) + peanut chaat / roasted chana  |  OR coconut water + handful makhana",
        benefit: "Maintains energy levels & reduces muscle fatigue"
      },
      {
        time: "Dinner (7:30–8:30 PM)",
        food: "2 roti + sabzi + paneer/dal",
        benefit: "No restriction on dinner quantity – focus on nourishment & recovery"
      }
    ],
    dailyAddons: {
      food: "1 tsp seeds mix (flax + pumpkin) + 1–2 tsp ghee daily",
      benefit: "Improves hormonal balance, hair health & supports weight gain"
    },
    specialFocus: {
      title: "Heavy Periods & Weakness",
      food: "Include beetroot, spinach, black raisins regularly",
      benefit: "Helps improve blood levels & reduces fatigue"
    },
    avoidFoods: [
      "Avoid junk, packaged food, excess sugar",
      "Limit tea/coffee (max 1–2 cups)",
      "Prevents further hormonal imbalance"
    ],
    hydration: "2.5–3 litres water daily",
    lifestyle: [
      "30 minutes light exercise or walk",
      "Proper sleep (7–8 hours)",
      "Avoid stress & late night eating"
    ],
    followUp: "Review after 15 days for weight and symptom improvement",
    note: "This diet is specifically designed for lean PCOD patients with weakness and heavy menstrual flow. Focus is on improving nutritional status, hormonal balance & gradual healthy weight gain."
  },

  weight_to_lean: {
    condition: "PCOD with Weight Gain, Acne, Hairfall & Irregular Periods",
    subtitle: "Diet planned considering hormonal imbalance, metabolism disturbance & digestive issues",
    meals: [
      {
        time: "Early Morning (7:00–8:00 AM)",
        food: "1 glass lukewarm water + lemon (without sugar) + 1 tsp soaked methi seeds",
        benefit: "Helps improve digestion, reduce bloating & support fat metabolism"
      },
      {
        time: "Breakfast (8:30–9:30 AM)",
        food: "Option 1: 2 besan chilla + curd  |  Option 2: Vegetable oats + seeds mix  |  Option 3: 2 eggs + 1 multigrain toast",
        benefit: "High protein breakfast helps reduce acne, hairfall & controls cravings"
      },
      {
        time: "Mid-Morning (11:00–12:00 PM)",
        food: "1 fruit (apple/guava/papaya)",
        benefit: "Maintains energy levels & prevents overeating"
      },
      {
        time: "Lunch (1:30–2:30 PM)",
        food: "2 multigrain roti + 1 bowl sabzi + 1 bowl dal/paneer + salad before meal",
        benefit: "Balanced meal supports hormonal balance & weight control"
      },
      {
        time: "Evening Snack (5:00–6:00 PM)",
        food: "Green tea / normal tea (without sugar) + roasted chana / makhana",
        benefit: "Controls cravings & supports metabolism"
      },
      {
        time: "Dinner (7:30–8:30 PM)",
        food: "1–2 roti + sabzi OR vegetable soup + paneer",
        benefit: "Light dinner helps reduce bloating & supports fat loss"
      }
    ],
    dailyAddons: {
      food: "Flax seeds – 1 tsp, Pumpkin seeds – 1 tsp, 2 walnuts",
      benefit: "Supports hormonal balance, reduces acne & hairfall"
    },
    avoidFoods: [
      "Avoid sugar, bakery, fried & packaged food",
      "Limit rice, potato, banana, mango",
      "Reduce excess tea/coffee"
    ],
    hydration: "2.5–3 litres water daily",
    lifestyle: [
      "30–40 min daily walk/exercise",
      "Proper sleep (7–8 hrs)",
      "Avoid late night eating"
    ],
    followUp: "Review after 15 days",
    note: "This diet focuses on hormonal balance, weight reduction & improvement in skin and hair health."
  },

  infertility_pcod_pcos: {
    condition: "PCOD with Irregular Periods & Infertility Concerns",
    subtitle: "Diet planned considering hormonal imbalance, ovulation support & reproductive health",
    meals: [
      {
        time: "Early Morning (7:00–8:00 AM)",
        food: "Lukewarm water + 1 tsp soaked methi seeds OR 2 walnuts",
        benefit: "Supports hormonal balance & ovulation function"
      },
      {
        time: "Breakfast (High Protein)",
        food: "Besan chilla + curd  /  Eggs + toast  /  Oats + seeds",
        benefit: "Improves egg quality & stabilizes hormones"
      },
      {
        time: "Mid-Morning",
        food: "1 fruit (apple/guava/papaya)",
        benefit: "Maintains energy & prevents hormonal fluctuations"
      },
      {
        time: "Lunch",
        food: "2 roti + sabzi + dal/paneer + salad",
        benefit: "Balanced nutrition supports reproductive system"
      },
      {
        time: "Evening Snack",
        food: "Green tea / normal tea (no sugar) + roasted chana/makhana",
        benefit: "Controls cravings & supports metabolism"
      },
      {
        time: "Dinner (Light & Early)",
        food: "1–2 roti + sabzi OR soup + paneer",
        benefit: "Improves digestion & supports hormonal recovery"
      }
    ],
    dailyAddons: {
      food: "Flax seeds, pumpkin seeds, walnuts",
      benefit: "Supports ovulation, hormone balance & fertility"
    },
    specialFocus: {
      title: "Reproductive Health",
      food: "Include leafy greens, beetroot, nuts, seeds regularly",
      benefit: "Improves blood flow & reproductive health"
    },
    avoidFoods: [
      "Sugar, junk food, packaged food, excess caffeine",
      "Prevents hormonal imbalance"
    ],
    lifestyle: [
      "30–40 min walk daily",
      "Stress management",
      "Proper sleep",
      "Regular cycle support is essential"
    ],
    followUp: "Review after 15 days"
  },

  thyroid_diabetes_pcod: {
    condition: "PCOD with Thyroid Imbalance, Sugar Tendency, Leucorrhea & Weakness",
    subtitle: "Diet planned considering hormonal imbalance, metabolism disturbance & nutritional deficiency",
    meals: [
      {
        time: "Early Morning (7:00–8:00 AM)",
        food: "Lukewarm water + 1 tsp soaked methi seeds",
        benefit: "Helps control sugar levels & supports hormonal balance"
      },
      {
        time: "Breakfast (High Protein)",
        food: "Besan chilla + curd  /  Eggs + toast  /  Vegetable oats + seeds",
        benefit: "Supports thyroid, reduces hairfall & controls cravings"
      },
      {
        time: "Mid-Morning",
        food: "1 fruit (apple/guava/papaya)",
        benefit: "Maintains steady energy levels"
      },
      {
        time: "Lunch",
        food: "2 roti + sabzi + dal/paneer + salad",
        benefit: "Improves digestion & supports hormones"
      },
      {
        time: "Evening Snack",
        food: "Tea (no sugar) + roasted chana/makhana",
        benefit: "Prevents weakness & cravings"
      },
      {
        time: "Dinner",
        food: "1–2 roti + sabzi OR soup + paneer",
        benefit: "Light dinner improves metabolism & reduces bloating"
      }
    ],
    dailyAddons: {
      food: "Flax seeds, pumpkin seeds, walnuts, black raisins",
      benefit: "Helps in hairfall, weakness & hormonal balance"
    },
    specialFocus: {
      title: "Leucorrhea & Overall Health",
      food: "Curd (daytime), coconut water, green vegetables",
      benefit: "Supports leucorrhea & overall health"
    },
    avoidFoods: [
      "Sugar, junk food, packaged food",
      "Limit tea/coffee"
    ],
    lifestyle: [
      "Daily walk",
      "Proper sleep",
      "Stress management"
    ],
    followUp: "Review after 15 days"
  },

  general_pcod_pcos: {
    condition: "PCOD with Irregular Periods (General Type)",
    subtitle: "Plan focuses on regulating hormones, improving ovulation and stabilizing insulin levels",
    understandingItems: [
      "Irregular periods are mainly due to hormonal imbalance.",
      "This plan focuses on regulating hormones, improving ovulation and stabilizing insulin levels."
    ],
    meals: [
      {
        time: "Morning Hormone Reset Routine",
        items: [
          "Warm water with soaked methi seeds (4–5 seeds, 4 times/week)",
          "2 soaked walnuts + 5 almonds",
          "10–15 min sunlight exposure for Vitamin D",
          "Light stretching or breathing exercises"
        ]
      },
      {
        time: "Breakfast (High Protein – Must)",
        items: [
          "Paneer bhurji / Eggs / Moong dal chilla",
          "Add 1 tsp flaxseed powder (estrogen balance)",
          "Avoid bread, biscuits, sugary cereals",
          "Tea/coffee without excess sugar"
        ]
      },
      {
        time: "Mid-Morning Hormone Snack",
        items: [
          "Low GI fruit: Apple / Guava / Papaya",
          "1 tsp pumpkin seeds (zinc for hormone support)",
          "Avoid fruit juices"
        ]
      },
      {
        time: "Lunch (Balanced Plate)",
        items: [
          "1–2 roti (multigrain) + sabzi + dal",
          "Include leafy greens (spinach, methi)",
          "1 bowl curd (skip if white discharge)",
          "Avoid fried/oily food"
        ]
      },
      {
        time: "Evening Cortisol Control Snack",
        items: [
          "Herbal tea (cinnamon + tulsi)",
          "Roasted chana / makhana",
          "Avoid biscuits, namkeen"
        ]
      },
      {
        time: "Dinner (Light & Early)",
        items: [
          "Dal + sabzi + 1 roti",
          "1 tsp sesame seeds (cycle regulation)",
          "Finish dinner before 8:30 PM",
          "Avoid heavy carbs at night"
        ]
      }
    ],
    advancedTips: [
      "Seed Cycling: flax + pumpkin (first half cycle), sesame + sunflower (second half)",
      "Protein in every meal improves ovulation",
      "Avoid cold foods during periods",
      "Sleep before 11 PM (melatonin-hormone link)",
      "Daily 20–30 min walk"
    ],
    lifestyle: [
      "Manage stress (yoga, breathing, journaling)",
      "Avoid late nights",
      "Stay hydrated (2–3 litres water)",
      "Consistency is key for results"
    ],
    note: "This is a general plan. Follow consistently for 6–8 weeks for visible results."
  },

  pcod_mood_anxiety_insomnia: {
    condition: "PCOD with Mood Swings, Anxiety, Overthinking & Insomnia",
    subtitle: "Diet planned considering hormonal imbalance, stress factors & nervous system support",
    meals: [
      {
        time: "Early Morning (7:00–8:00 AM)",
        food: "Lukewarm water + 2 walnuts + 4 soaked almonds",
        benefit: "Supports brain health & reduces anxiety"
      },
      {
        time: "Breakfast (High Protein + Brain Support)",
        food: "Besan chilla + curd / Eggs + toast / Oats + seeds",
        benefit: "Stabilizes mood & reduces cravings"
      },
      {
        time: "Mid-Morning",
        food: "1 fruit (banana/apple/papaya)",
        benefit: "Maintains energy & prevents irritability"
      },
      {
        time: "Lunch",
        food: "2 roti + sabzi + dal/paneer + salad",
        benefit: "Balanced meal supports hormones & mental stability"
      },
      {
        time: "Evening Snack",
        food: "Herbal tea / normal tea (no sugar) + makhana/chana",
        benefit: "Prevents anxiety spikes in evening"
      },
      {
        time: "Dinner (Light & Early)",
        food: "1–2 roti + sabzi OR soup + paneer",
        benefit: "Light dinner improves sleep quality"
      }
    ],
    dailyAddons: {
      food: "Flax seeds, pumpkin seeds, walnuts",
      benefit: "Supports hormonal balance & brain function"
    },
    specialFocus: {
      title: "Sleep Support Routine",
      food: "1 glass warm milk at night (if suits) or chamomile tea",
      benefit: "Avoid phone 30–45 mins before sleep"
    },
    avoidFoods: [
      "Caffeine excess, sugar, late night eating, junk food",
      "These worsen anxiety & sleep disturbance"
    ],
    lifestyle: [
      "30 min walk, deep breathing, proper sleep routine",
      "Stress management is essential for recovery"
    ],
    followUp: "Review after 15 days"
  }
};
